import Image from "next/image";
import { type LucideIcon } from "lucide-react";
import { useTranslations } from "next-intl";
import "./hero-flow.css";

const methods: {
  key: string;
  icon?: LucideIcon;
  avatar?: string;
  logos?: { src: string; width: number; height: number }[];
}[] = [
  {
    key: "mobileMoney",
    avatar: "/assets/hero/payment-avatar-mobile-money.png",
    logos: [
      { src: "/assets/partners/mtn-momo.jpg", width: 42, height: 36 },
      { src: "/assets/partners/orange-money.png", width: 50, height: 35 },
    ],
  },
  {
    key: "bankCards",
    avatar: "/assets/hero/payment-avatar-bank-card.png",
    logos: [
      { src: "/assets/partners/visa.png", width: 48, height: 16 },
      { src: "/assets/partners/mastercard.png", width: 22, height: 22 },
    ],
  },
  {
    key: "wallets",
    avatar: "/assets/hero/payment-avatar-wallet.png",
    logos: [{ src: "/assets/partners/paypal.png", width: 52, height: 26 }],
  },
  {
    key: "bankTransfers",
    avatar: "/assets/hero/payment-avatar-bank-transfer.png",
    logos: [
      { src: "/assets/partners/uba.gif", width: 36, height: 22 },
      { src: "/assets/partners/afb.png", width: 48, height: 14 },
    ],
  },
  {
    key: "otherPayments",
    avatar: "/assets/hero/payment-avatar-other.png",
    logos: [
      { src: "/assets/partners/unionpay.png", width: 38, height: 24 },
      { src: "/assets/partners/stripe.png", width: 42, height: 18 },
    ],
  },
  { key: "cemac", avatar: "/assets/hero/cemac-logo.png" },
] as const;

export function HeroFlow() {
  const t = useTranslations("hero");
  const wirePositions = [274, 291] as const;

  return (
    <div className="hf" role="group" aria-label={t("flowLabel")}>
      <div className="hf-stage">
        {wirePositions.map((junction, index) => (
          <svg
            key={junction}
            className={`hf-wires ${index === 0 ? "hf-wires-wide" : "hf-wires-compact"}`}
            viewBox="0 0 650 410"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            <path className="hf-wire hf-wire-blue" d={`M190 38 C268 38 260 205 ${junction} 205`} />
            <path className="hf-wire hf-wire-green" d={`M190 105 C266 105 273 205 ${junction} 205`} />
            <path className="hf-wire hf-wire-purple" d={`M190 171 C261 171 279 205 ${junction} 205`} />
            <path className="hf-wire hf-wire-orange" d={`M190 239 C261 239 279 205 ${junction} 205`} />
            <path className="hf-wire hf-wire-cyan" d={`M190 305 C266 305 273 205 ${junction} 205`} />
            <path className="hf-wire hf-wire-gold" d={`M190 372 C268 372 260 205 ${junction} 205`} />
          </svg>
        ))}

        <div className="hf-methods">
          <span className="hf-caption">{t("methodsTitle")}</span>
          <div className="hf-method-list">
            {methods.map(({ key, icon: Icon, avatar, logos: methodLogos }) => (
              <div className={`hf-method hf-method-${key}`} key={key}>
                {avatar ? (
                  <Image className="hf-method-avatar" src={avatar} alt="" width={36} height={36} />
                ) : Icon ? (
                  <span className="hf-method-icon"><Icon size={16} /></span>
                ) : null}
                <span className="hf-method-label">{t(key)}</span>
                {methodLogos ? (
                  <span className="hf-method-logos">
                    {methodLogos.map((logo) => (
                      <Image
                        key={logo.src}
                        src={logo.src}
                        alt=""
                        width={logo.width}
                        height={logo.height}
                        unoptimized={logo.src.endsWith(".gif")}
                      />
                    ))}
                  </span>
                ) : null}
              </div>
            ))}
          </div>
        </div>

        <div className="hf-hub">
          <Image src="/assets/brand/biapay-wordmark.webp" alt="" width={220} height={50} />
        </div>

        <div className="hf-merchant">
          <Image
            src="/assets/hero/particular.jpg"
            alt=""
            fill
            priority
            sizes="(max-width: 760px) 90vw, 320px"
          />
          <span className="hf-merchant-tag">{t("merchant")}</span>
        </div>
      </div>
    </div>
  );
}
