import { ViewTransition, type ReactNode } from "react";

const transitionClasses = {
  "solution-forward": "solution-forward",
  "solution-back": "solution-back",
  default: "none",
} as const;

export function PageTransition({ children }: { children: ReactNode }) {
  return (
    <ViewTransition
      enter={transitionClasses}
      exit={transitionClasses}
      default="none"
    >
      {children}
    </ViewTransition>
  );
}
