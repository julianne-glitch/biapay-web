"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Menu, X } from "lucide-react";
import { useTranslations } from "next-intl";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { Link, usePathname } from "@/i18n/navigation";
import { accountLinks } from "@/lib/shell-nav";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const t = useTranslations("nav");
  const account = useTranslations("account");
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [compact, setCompact] = useState(false);

  useEffect(() => {
    const onScroll = () => setCompact(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/70 bg-white/70 px-5 shadow-[0_8px_30px_rgba(14,46,87,0.08)] backdrop-blur-2xl sm:px-8">
      <div className={cn(
        "mx-auto grid w-full max-w-[1440px] grid-cols-[1fr_auto] items-center gap-4 transition-[min-height] duration-300 motion-reduce:transition-none min-[1120px]:grid-cols-[auto_1fr_auto]",
        compact ? "min-h-[64px]" : "min-h-[78px]",
      )}>
        <Link href="/" className="w-fit shrink-0" aria-label="BIAPAY">
          <Image
            src="/assets/brand/biapay-wordmark.webp"
            alt="BIAPAY"
            width={220}
            height={50}
            priority
            className={cn("h-auto w-[150px] transition-all duration-300 sm:w-[176px]", compact && "sm:w-[160px]")}
          />
        </Link>

        <nav aria-label={t("primary")} className="hidden min-[1120px]:flex min-[1120px]:justify-center">
          <NavLinks pathname={pathname} />
        </nav>

        <div className="hidden items-center gap-3 min-[1120px]:flex">
          <LanguageSwitcher />
          <a
            href={accountLinks.login}
            target="_blank"
            rel="noopener noreferrer"
            className="whitespace-nowrap rounded-full border border-white/90 bg-white/45 px-5 py-2.5 text-sm font-semibold text-[#123f98] shadow-[inset_0_1px_0_rgba(255,255,255,0.9),0_6px_18px_rgba(18,63,152,0.08)] backdrop-blur-md transition-all duration-200 hover:-translate-y-0.5 hover:bg-white/75"
          >
            {account("login")}
          </a>
          <a
            href={accountLinks.register}
            className="whitespace-nowrap rounded-full border border-white/35 bg-[#153f91]/85 px-5 py-2.5 text-sm font-semibold text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.28),0_8px_20px_rgba(21,63,145,0.2)] backdrop-blur-md transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#0d347f]/95"
          >
            {account("register")}
          </a>
        </div>

        <button
          type="button"
          className="inline-flex size-10 items-center justify-center justify-self-end rounded-full border border-white/80 bg-white/50 text-[#123f98] shadow-[0_4px_14px_rgba(18,63,152,0.08)] backdrop-blur-md transition-colors hover:bg-white/80 min-[1120px]:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? t("closeMenu") : t("openMenu")}
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
        </button>
      </div>

      {open ? (
        <div id="mobile-nav" className="mx-auto mb-4 max-w-[1440px] rounded-2xl border border-white/75 bg-white/75 px-4 py-4 shadow-[0_12px_34px_rgba(8,45,112,.12)] backdrop-blur-2xl min-[1120px]:hidden">
          <NavLinks pathname={pathname} onNavigate={() => setOpen(false)} />
          <div className="mt-4 flex flex-col gap-4 border-t border-[#e5ebf4] pt-4">
            <LanguageSwitcher />
            <a href={accountLinks.login} target="_blank" rel="noopener noreferrer" className="rounded-full border border-white/85 bg-white/50 px-5 py-3 text-sm font-semibold text-[#123f98] shadow-[inset_0_1px_0_rgba(255,255,255,0.9),0_4px_14px_rgba(18,63,152,0.08)] backdrop-blur-md">
              {account("login")}
            </a>
            <a href={accountLinks.register} className="rounded-full border border-white/35 bg-[#153f91]/85 px-5 py-3 text-center text-sm font-semibold text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.28),0_8px_20px_rgba(21,63,145,0.2)] backdrop-blur-md">
              {account("register")}
            </a>
          </div>
        </div>
      ) : null}
    </header>
  );
}

function NavLinks({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  const t = useTranslations("nav");
  const items = [
    { key: "merchants", href: "/pricing", active: pathname.startsWith("/pricing") },
    { key: "customers", href: "/#solutions", active: false },
    { key: "developers", href: "/developers", active: pathname.startsWith("/developers") },
    { key: "about", href: "/about", active: pathname.startsWith("/about") },
    { key: "support", href: "/resources", active: pathname.startsWith("/resources") },
  ] as const;

  return (
    <ul className="flex flex-col gap-1 min-[1120px]:flex-row min-[1120px]:items-center min-[1120px]:gap-1">
      {items.map((item) => (
        <li key={item.key}>
          <Link
            href={item.href}
            onClick={onNavigate}
            aria-current={item.active ? "page" : undefined}
            className={cn(
              "relative flex items-center gap-1 rounded-full px-3 py-2 text-sm font-semibold text-[#153770] transition-all hover:bg-white/60 hover:text-[#0b60d8] hover:shadow-[0_4px_14px_rgba(18,63,152,0.08)] min-[1120px]:px-3.5",
              item.active && "bg-white/55 shadow-[inset_0_1px_0_rgba(255,255,255,0.9)] after:absolute after:inset-x-3.5 after:-bottom-1 after:h-[3px] after:rounded-full after:bg-[#77bf35]",
            )}
          >
            {t(item.key)}
          </Link>
        </li>
      ))}
    </ul>
  );
}
