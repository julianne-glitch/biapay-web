import { getRequestConfig } from "next-intl/server";
import { routing } from "./routing";
import { isLocale } from "@/lib/shell-nav";

export default getRequestConfig(async ({ requestLocale }) => {
  const requested = await requestLocale;
  const locale = requested && isLocale(requested) ? requested : routing.defaultLocale;

  return {
    locale,
    messages: (await import(`../../messages/${locale}.json`)).default,
  };
});
